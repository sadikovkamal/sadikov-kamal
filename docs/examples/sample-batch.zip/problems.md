---
source: S000005
age_categories: [A000011]
topics: [T000003]
---

# Shart

Barcha musbat butun sonlar $n$ ni topingki, $n^2 + 1$ soni $n + 1$ ga
qoldiqsiz bo'linsin.

---

source: S000005
age_categories: [A000010, A000011]
topics: [T000001, T000005]
---

# Shart

$a, b, c$ musbat haqiqiy sonlar bo'lib, $abc = 1$ shartni qanoatlantiradi.
Quyidagini isbotlang:

$$\frac{1}{a} + \frac{1}{b} + \frac{1}{c} \geq a + b + c$$

---

source: S000007
age_categories: [A000009]
topics: [T000002]
---

# Shart

$ABC$ uchburchakka ichki chizilgan aylana $BC$ tomonga $D$ nuqtada,
$CA$ tomonga $E$ nuqtada va $AB$ tomonga $F$ nuqtada tegadi. Isbotlangki,
$AD$, $BE$ va $CF$ kesmalar bitta nuqtada kesishadi.

![Uchburchakka chizilgan ichki aylana](images/problem-3.png)

---

source: S000006
age_categories: [A000011]
topics: [T000004]
---

# Shart

$8 \times 8$ shaxmat doskasidan ikkita qarama-qarshi burchak katakchasi
olib tashlangan. Qolgan $62$ ta katakni $1 \times 2$ o'lchamli domino
toshlari bilan to'liq qoplash mumkinmi? Javobni asoslang.

![Shaxmat doskasidan ikkita katak olib tashlangan](images/problem-4.png)

---

source: S000008
age_categories: [A000007, A000008]
topics: [T000001]
---

# Shart

Tenglamani yeching:

$$x^2 - 5x + 6 = 0$$

Yechimlarning yig'indisi va ko'paytmasi Viet teoremasiga mos kelishini
tekshiring.
