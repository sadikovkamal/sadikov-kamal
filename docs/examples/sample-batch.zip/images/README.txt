Shu papkaga rasm fayllarini joylang.

Hozirgi problems.md quyidagilarni izlaydi:
  - problem-3.png  (3-masala: uchburchakka chizilgan ichki aylana)
  - problem-4.png  (4-masala: shaxmat doskasi)

Qo'llab-quvvatlanadigan formatlar: PNG, JPG, GIF, WebP, SVG.
Har bir rasm uchun maksimal hajm: 5 MB.

Eslatma: har bir masalada eng ko'pi bilan 1 ta rasm bo'lishi mumkin.
